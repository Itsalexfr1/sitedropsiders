(function() {
    console.log("[Dropsiders] Presence script loading...");

    const presence = new Presence({
        clientId: "1481163258080788602"
    });

    presence.on("Update", () => {
        const data = {
            details: "Média Hardstyle #1",
            state: "Exploration du contenu",
            largeImageKey: "https://dropsiders.fr/logo_presentation.png",
            largeImageText: "Dropsiders",
            startTimestamp: Date.now()
        };

        const path = window.location.pathname;
        if (path.includes("/news")) data.details = "Lit une News";
        else if (path.includes("/agenda")) data.details = "Consulte l'Agenda";
        else if (path.includes("/live")) data.details = "Écoute le Live 🔴";
        else if (path === "/") data.details = "Page d'Accueil";

        presence.setActivity(data);
        console.log("[Dropsiders] Activity updated!");
    });
})();
